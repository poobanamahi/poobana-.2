#!/bin/bash
git init
git status
git add welcome.txt
git commit -m "Initial commit with welcome.txt"
# Replace <your-repo-url> with your actual GitHub/GitLab repo URL
# git remote add origin <your-repo-url>
# git push -u origin master
